<a href="#" class="mkdf-login-opener">
    <span class="mkdf-login-text"><?php esc_html_e('Login / Register', 'biagiotti-membership'); ?></span>
</a>