<?php

include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/login/functions.php';
include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/login/login.php';