<?php

include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/functions.php';
include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/reset-password/reset-password.php';