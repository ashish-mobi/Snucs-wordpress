<?php

include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/register/functions.php';
include_once BIAGIOTTI_MEMBERSHIP_SHORTCODES_PATH . '/register/register.php';