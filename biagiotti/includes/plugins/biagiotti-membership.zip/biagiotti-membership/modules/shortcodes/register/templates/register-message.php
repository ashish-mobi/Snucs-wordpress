<div class="mkdf-register-notice">
	<h5 class="mkdf-register-notice-title"><?php echo esc_html($message); ?></h5>
	<a href="#" class="mkdf-login-popup-close-btn mkdf-btn mkdf-btn-simple"><?php esc_html_e('Close', 'biagiotti-membership'); ?></a>
</div>