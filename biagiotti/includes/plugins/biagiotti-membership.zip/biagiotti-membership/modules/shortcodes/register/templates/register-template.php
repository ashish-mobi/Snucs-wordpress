<div class="mkdf-social-register-holder">
	<form method="post" class="mkdf-register-form">
		<fieldset>
			<div>
				<input type="text" name="user_register_name" id="user_register_name" placeholder="<?php esc_html_e( 'Username*', 'biagiotti-membership' ); ?>" value="" required pattern=".{3,}" title="<?php esc_attr_e( 'Three or more characters', 'biagiotti-membership' ); ?>"/>
			</div>
			<div>
				<input type="email" name="user_register_email" id="user_register_email" placeholder="<?php esc_html_e( 'Email*', 'biagiotti-membership' ); ?>" value="" required />
			</div>
            <div>
                <input type="password" name="user_register_password" id="user_register_password" placeholder="<?php esc_html_e( 'Password*', 'biagiotti-membership' ); ?>" value="" required />
            </div>
            <div>
                <input type="password" name="user_register_confirm_password" id="user_register_confirm_password"  placeholder="<?php esc_html_e( 'Repeat Password*', 'biagiotti-membership' ); ?>" value="" required />
            </div>
            <?php do_action('biagiotti_membership_additional_registration_field'); ?>
			<div class="mkdf-register-button-holder">
				<?php
				if ( biagiotti_membership_theme_installed() ) {
					echo biagiotti_mikado_get_button_html( array(
						'html_type'              => 'button',
						'text'                   => esc_html__( 'Register', 'biagiotti-membership' ),
						'type'                   => 'outline',
						'size'                   => 'medium'
					) );
				} else {
					echo '<button type="submit">' . esc_html__( 'Register', 'biagiotti-membership' ) . '</button>';
				}
				wp_nonce_field( 'mkdf-ajax-register-nonce', 'mkdf-register-security' ); ?>
			</div>
		</fieldset>
	</form>
	<?php do_action( 'biagiotti_membership_action_login_ajax_response' ); ?>
</div>