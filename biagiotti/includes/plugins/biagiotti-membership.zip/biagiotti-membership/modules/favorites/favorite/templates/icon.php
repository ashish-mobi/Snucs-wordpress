<a href="javascript:void(0)" class="mkdf-membership-item-favorites mkdf-icon-only" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="mkdf-favorites-icon <?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
</a>