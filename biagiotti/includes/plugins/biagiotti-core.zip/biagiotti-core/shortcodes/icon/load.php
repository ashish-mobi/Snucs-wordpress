<?php

include_once BIAGIOTTI_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once BIAGIOTTI_CORE_SHORTCODES_PATH . '/icon/icon.php';