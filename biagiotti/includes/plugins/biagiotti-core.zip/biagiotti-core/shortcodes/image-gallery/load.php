<?php

include_once BIAGIOTTI_CORE_SHORTCODES_PATH . '/image-gallery/functions.php';
include_once BIAGIOTTI_CORE_SHORTCODES_PATH . '/image-gallery/image-gallery.php';