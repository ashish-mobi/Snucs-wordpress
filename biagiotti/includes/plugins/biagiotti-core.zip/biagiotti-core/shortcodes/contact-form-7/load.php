<?php

include_once BIAGIOTTI_CORE_SHORTCODES_PATH . '/contact-form-7/functions.php';
