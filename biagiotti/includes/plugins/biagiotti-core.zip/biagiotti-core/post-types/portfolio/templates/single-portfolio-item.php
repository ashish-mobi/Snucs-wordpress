<?php

get_header();

biagiotti_mikado_get_title();

do_action('biagiotti_mikado_action_before_main_content');

biagiotti_core_get_single_portfolio();

get_footer();