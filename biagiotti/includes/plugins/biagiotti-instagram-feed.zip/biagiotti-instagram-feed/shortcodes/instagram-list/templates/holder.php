<div class="mkdf-instagram-list-holder <?php echo esc_attr($outer_classes); ?>">
    <?php if ( is_array( $images_array ) && count( $images_array ) ) { ?>
	    <ul class="mkdf-instagram-feed mkdf-outer-space <?php echo esc_attr($holder_classes); ?> clearfix" <?php echo biagiotti_mikado_get_inline_attrs( $data_attr ) ?>>
	    <?php
	    foreach ( $images_array as $image ) { ?>
		    <li class="mkdf-il-item mkdf-item-space">
			    <a href="<?php echo esc_url( $instagram_api->getHelper()->getImageLink( $image ) ); ?>" target="_blank">
				    <?php echo biagiotti_mikado_kses_img( $instagram_api->getHelper()->getImageHTML( $image ) ); ?>
				    <?php if ($show_instagram_icon =='yes' ) { ?>
                        <span class="mkdf-instagram-icon"><i class="ion-social-instagram-outline"></i></span>
				    <?php } ?>
			    </a>
		    </li>
	    <?php } ?>
    </ul>
    <?php } else { ?>
        <div class="mkdf-instagram-not-connected">
            <?php esc_html_e( 'It seams that you haven\'t connected with your Instagram account', 'estelle-instagram-feed' ); ?>
        </div>
    <?php } ?>
	<?php if ( $show_instagram_info === 'yes' ) { ?>
		<div class="mkdf-instagram-info">
			<?php if ( ! empty( $tagline ) ) { ?>
				<div class="mkdf-instagram-tagline"><?php echo esc_html( $tagline ); ?></div>
			<?php } ?>
			<?php if ( ! empty( $title ) ) { ?>
				<h2 class="mkdf-instagram-title"><?php echo esc_html( $title ); ?></h2>
			<?php } ?>
			<?php if ( ! empty( $subtitle ) ) { ?>
				<div class="mkdf-instagram-subtitle"><?php echo esc_html( $subtitle ); ?></div>
			<?php } ?>
		</div>
	<?php } ?>
</div>